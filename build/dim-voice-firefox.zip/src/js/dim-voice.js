// get html elements
let searchBar = document.getElementsByName('filter').length > 0 ? document.getElementsByName('filter')[0] : null;
let dblClick = new Event('dblclick', {
  bubbles: true,
  cancelable: true,
  view: window
});

let inputEvent = new Event("input", { bubbles: true });
let enterEvent = new KeyboardEvent("keydown", { bubbles: true, which: 13, key: "enter" });

function setHtmlElements() {
  searchBar = document.getElementsByName('filter').length > 0 ? document.getElementsByName('filter')[0] : null;
  observer.disconnect();
}

function setNativeValue(element, value) {
  const valueSetter = Object.getOwnPropertyDescriptor(element, 'value').set;
  const prototype = Object.getPrototypeOf(element);
  const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value').set;

  if (valueSetter && valueSetter !== prototypeValueSetter) {
    prototypeValueSetter.call(element, value);
  } else {
    valueSetter.call(element, value);
  }
}



const weaponTypeQueries = {
  "auto rifle": "is:autorifle",
  "autorifle": "is:autorifle",
  "hand cannon": "is:handcannon",
  "pulse rifle": "is:pulserifle",
  "scout rifle": "is:scoutrifle",
  "sidearm": "is:sidearm",
  "submachine gun": "is:submachinegun",
  "bow": "is:bow",
  "shotgun": "is:shotgun",
  "sniper rifle": "is:sniperrifle",
  "fusion rifle": "is:fusionrifle",
  "trace rifle": "is:tracerifle",
  "grenade launcher": "is:grenadelauncher",
  "rocket launcher": "is:rocketlauncher",
  "linear fusion rifle": "is:linearfusionrifle",
  "machinegun": "is:machinegun",
  "machine gun": "is:machinegun",
  "sword": "is:sword",
}

const energyTypeQueries = {
  "arc": "is:arc",
  "solar": "is:solar",
  "void": "is:void",
  "stasis": "is:stasis",
}

const weaponSlotQueries = {
  "kinetic": "is:kinetic",
  "energy": "is:energy",
  "power": "is:power",
  "heavy": "is:power"
}

function parseSpeech(transcript) {

  let query = transcript.substring(3).trim();
  if (query.indexOf('transfer') === 0) {
    query = query.substring(8).toLowerCase().trim();
    // const weaponQueries = Object.keys(weaponTypeQueries);
    // const energyQueries = Object.keys(energyTypeQueries);
    // const slotQueries = Object.keys(weaponSlotQueries);

    const splitQuery = query.split(' ');
    let fullQuery = '';
    for (const weaponType of Object.keys(weaponTypeQueries)) {
      if (query.includes(weaponType)) {
        fullQuery += weaponTypeQueries[weaponType] + " ";
        break;
      }
    }

    for (const energyType of Object.keys(energyTypeQueries)) {
      if (query.includes(energyType)) {
        fullQuery += energyTypeQueries[energyType];
        break;
      }
    }

    for (const slotType of Object.keys(weaponSlotQueries)) {
      if (query.includes(slotType)) {
        fullQuery += weaponSlotQueries[slotType] + " ";
        break;
      }
    }

    fullQuery = fullQuery.trim();

    if (fullQuery === "") {
      const availableItems = getAllTransferableItems();
      const itemToGet = getClosestMatch(availableItems, query);
      const itemDiv = document.querySelector(`[title*="${itemToGet}" i`);
      if (itemDiv) {
        itemDiv.dispatchEvent(dblClick);
      }
    }
    else {
      console.log("Full query being sent to DIM: " + fullQuery);
      transferByWeaponTypeQuery(fullQuery);
    }

  }

}

const transferableItemClassNames = [
  "KineticSlot",
  "Energy",
  "Power",
  "Helmet",
  "Gauntlets",
  "Chest",
  "Leg",
  "ClassItem"
]

function getAllTransferableItems() {
  const items = [];
  for (const className of transferableItemClassNames) {
    const result = document.querySelectorAll(`.item-type-${className} .item`);
    result.forEach(item => {
      const split = item.title.split('\n');
      items.push(split[0]);
    });
  }

  return items;
}

function getClosestMatch(availableItems, query) {
  const options = {
    includeScore: true
  }

  const fuse = new Fuse(availableItems, options)

  const result = fuse.search(query);
  console.log({ result, query });
  return result.length > 0 ? result[0].item : "";
}

function transferByWeaponTypeQuery(searchInput) {
  if (searchBar) {
    // setNativeValue(searchBar, searchInput);
    searchBar.value = searchInput;
    const inputFunc = function () {
      searchBar.dispatchEvent(inputEvent);
    }

    const enterFunc = function () {
      searchBar.dispatchEvent(enterEvent);
    }

    const transferFunc = function () {
      const filteredItems = [...document.querySelectorAll("div.item")].filter(x => window.getComputedStyle(x, null).opacity > .2);
      console.log(filteredItems);
      if (filteredItems.length > 0) {
        filteredItems[0].dispatchEvent(dblClick);
      }
    }
    const actions = [{ func: inputFunc, timeout: 500 }, { func: enterFunc, timeout: 500 }, {
      func: transferFunc, timeout: 2000
    }];

    let totalTimeout = 0;
    for (let i = 0; i < actions.length; i++) {
      totalTimeout += actions[i].timeout;
      setTimeout(actions[i].func, totalTimeout);
    }
  }
}


if (!window.webkitSpeechRecognition) {
  console.log('Sorry this will work only in Chrome for now...');
}
const magic_word = 'dim';
// initialize our SpeechRecognition object
let recognition = new webkitSpeechRecognition();
recognition.lang = 'en-US';
recognition.interimResults = false;
recognition.maxAlternatives = 1;
recognition.continuous = true;


recognition.onresult = e => {
  var transcripts = [].concat.apply([], [...e.results].map(res => [...res].map(alt => alt.transcript)));
  if (transcripts.some(t => t.indexOf(magic_word) > -1)) {
    parseSpeech(transcripts.join(''))
  }
  else {
    console.log('understood ' + JSON.stringify(transcripts));
  }
}
// called when we detect silence
function stopSpeech() {
  recognition.stop();
}
// called when we detect sound
function startSpeech() {
  try { // calling it twice will throw...
    recognition.start();
  }
  catch (e) { }
}
// request a LocalMediaStream
navigator.mediaDevices.getUserMedia({ audio: true })
  // add our listeners
  .then(stream => detectSilence(stream, stopSpeech, startSpeech))
  .catch(e => console.error(e.message));


function detectSilence(
  stream,
  onSoundEnd = _ => { },
  onSoundStart = _ => { },
  silence_delay = 500,
  min_decibels = -80
) {
  const ctx = new AudioContext();
  const analyser = ctx.createAnalyser();
  const streamNode = ctx.createMediaStreamSource(stream);
  streamNode.connect(analyser);
  analyser.minDecibels = min_decibels;

  const data = new Uint8Array(analyser.frequencyBinCount); // will hold our data
  let silence_start = performance.now();
  let triggered = false; // trigger only once per silence event

  function loop(time) {
    requestAnimationFrame(loop); // we'll loop every 60th of a second to check
    analyser.getByteFrequencyData(data); // get current data
    if (data.some(v => v)) { // if there is data above the given db limit
      if (triggered) {
        triggered = false;
        onSoundStart();
      }
      silence_start = time; // set it to now
    }
    if (!triggered && time - silence_start > silence_delay) {
      onSoundEnd();
      triggered = true;
    }
  }
  loop();
}



let observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (!mutation.addedNodes) return;

    for (let i = 0; i < mutation.addedNodes.length; i++) {
      let node = mutation.addedNodes[i];
      console.log({ node })
      if (node.className.toLowerCase() == "search-link") {
        setHtmlElements();
        break;
      }
    }
  });
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  attributes: false,
  characterData: false,
});